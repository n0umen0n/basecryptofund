const express = require('express');
const fetch = require('node-fetch');
const { sign } = require('jsonwebtoken');
const crypto = require('crypto');
const { ethers } = require('ethers');
const cors = require('cors');

const app = express();
const port = 5000;


// Middleware to parse JSON bodies
app.use(express.json());
app.use(cors(
  {
  }
));
// Replace with your actual values

const request_method = 'GET';
const url = 'api.developer.coinbase.com';

// Ethereum provider and signer (replace with your actual provider and private key)
const wallet = new ethers.Wallet(privateKey, provider);

// Contract details
const contractAddress = '0x596D0a27C8dF154b50acD419AF4eFf60409a2592';
const abi = [ // Simplified ABI for the invest function
  "function invest(uint256 ethAmount, address recipient, bytes32 trxHash) external",
  "function getFundTokenUsdValue(address holder) public view returns (uint256)",
  "function calculateProfitOrLoss(address investor) public view returns (int256)"
];
const contract = new ethers.Contract(contractAddress, abi, wallet);

const generateJWT = (request_path) => {
  const algorithm = 'ES256';
  const uri = request_method + ' ' + url + request_path;

  const token = sign(
    {
      iss: 'coinbase-cloud',
      nbf: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 120,
      sub: key_name,
      uri,
    },
    key_secret,
    {
      algorithm,
      header: {
        kid: key_name,
        nonce: crypto.randomBytes(16).toString('hex'),
      },
    }
  );

  return token;
};

const fetchTransactions = async (ethAddress) => {
  const request_path = `/onramp/v1/buy/user/${ethAddress}/transactions`;
  const apiUrl = `https://${url}${request_path}`;
  const jwtToken = generateJWT(request_path);

  console.log(`Request path: ${request_path}`); // Debugging line
  console.log(`JWT Token: ${jwtToken}`); // Debugging line

  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${jwtToken}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`HTTP error! status: ${response.status}, body: ${errorBody}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    throw new Error(`Error fetching transactions: ${error.message}`);
  }
};

const callInvestFunction = async (ethAmount, recipient, trxHash) => {
  try {
    const gasPrice = await provider.getGasPrice();
    console.log('Gas price:', gasPrice.toString());
    console.log('Investing ETH:', ethAmount.toString());
    const tx = await contract.invest(ethAmount, recipient, trxHash, {
      gasPrice: gasPrice
  });
    await tx.wait();
    console.log('Investment transaction successful:', tx);
  } catch (error) {
    console.error('Error calling invest function:', error);
    throw new Error('Failed to call invest function');
  }
};

app.post('/transactions', async (req, res) => {
  const { ethAddress } = req.body;

  console.log('Investment request received for address:', ethAddress); // Debugging line

  try {
    const transactions = await fetchTransactions(ethAddress);

    if(transactions.transactions[0].wallet_address == contractAddress) {
      console.log("TRX address matches our contract.")
    }
    else {
      console.log("TRX address does not match our contract.")
      res.json({ error: "TRX address does not match our contract." });
      return;
    }

    // Assuming we get the ethAmount and recipient from the transactions data for demonstration
    // You need to modify this based on your actual logic and data structure
    const ethAmount = ethers.utils.parseEther(transactions.transactions[0].purchase_amount.value);
    const trxHash = transactions.transactions[0].tx_hash;
    const recipient = ethAddress;

    console.log(`Investing ${ethAmount} ETH for ${recipient} and saving hash ${trxHash}`); // Debugging line

    // Call the invest function before sending the response
    await callInvestFunction(ethAmount, recipient, trxHash);

    res.json(transactions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/fundTokenUsdValue/:holder', async (req, res) => {
  const holder = req.params.holder;
  console.log(`Getting USD value for holder: ${holder}`);
  try {
      const value = await contract.getFundTokenUsdValue(holder);
      console.log(`USD value for holder ${holder}: ${ethers.utils.formatUnits(value, 6)}`);
      res.json({ usdValue: Number(ethers.utils.formatUnits(value, 6)) });
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
});


// Endpoint to calculate profit or loss for an investor
app.get('/profitOrLoss/:investor', async (req, res) => {
  const investor = req.params.investor;
  console.log(`Calculating profit or loss for investor: ${investor}`)
  try {
    const profitOrLoss = await contract.calculateProfitOrLoss(investor);
    console.log(`Profit or loss for investor ${investor}: ${ethers.utils.formatUnits(profitOrLoss, 6)}`);
    res.json({ profitOrLoss: Number(ethers.utils.formatUnits(profitOrLoss, 6)) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


app.listen(process.env.PORT || port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
